# Music bot – Railway ready

## Deploy (3 steps)
1. Put all these files in a **private** GitHub repo (the `.env` holds your secrets).
2. Railway → New Project → Deploy from GitHub repo → pick it. Railway finds the `Dockerfile` itself.
3. Done. Settings are read from `.env`. (Optional, safer: add API_ID, API_HASH, BOT_TOKEN, SESSION_STRING
   in Railway → Variables and delete `.env` from the repo – Variables always win over `.env`.)

## How it stays alive
- `main.py` restarts `bot.py` forever if it exits, and Railway restarts the container if that ever dies.
- A watchdog restarts the bot if Telegram stops answering for ~3 minutes.
- A song that can't be played is skipped; a stream that dies instantly is retried from another source.
- yt-dlp is updated on every start (YouTube changes often).

## Music sources (tried in this order, automatically)
YouTube (4 client methods) → SoundCloud → Piped (YouTube mirrors) → Audius.
Optional extra sources via variables: `SAAVN_API`, `JAMENDO_CLIENT_ID`. Change order with `SOURCE_ORDER`.
A source that keeps failing is paused for 30s–10min so it never slows the bot down.

## Files
bot.py (bot) · sources.py (all music sources) · main.py (supervisor + health check) · config.py ·
Dockerfile · railway.json · requirements.txt · cookies.txt · .env
